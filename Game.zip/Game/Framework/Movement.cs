﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Framework
{
    public interface Movement
    {
        void movement(int speed , PictureBox picture);
        int getvalue();
        //void movement(int speed, PictureBox picture,KeyEventArgs e);
        //Movement newState();
    }
}
