﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                pictureBox2.Top += 10;
            }
            if (e.KeyCode == Keys.Up)
            {
                pictureBox2.Top -= 10;
            }
            if (e.KeyCode == Keys.Left)
            {
                pictureBox2.Left -= 10;
            }
            if (e.KeyCode == Keys.Right)
            {
                pictureBox2.Left += 10;
            }
        }
    
        public void intersect()
        {
            int s= pictureBox1.Top;
            if (pictureBox2.Top == pictureBox1.Top+10) {
                pictureBox2.Visible = false;
            }
        } 
    }
}
